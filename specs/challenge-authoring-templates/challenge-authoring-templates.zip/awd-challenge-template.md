# AWD 题目交付模板

复制后填写本文件。不要记录真实比赛 Flag、JWT、密钥或私有仓库密码。合约以 [AWD 规则](../awd-rules-2026.zh-CN.md) 和 [制作规范](../challenge-authoring-awd-awdp.md) 为准。

## 题目与命名服务

| 项目 | 内容 |
| --- | --- |
| 题名、方向、Owner、Manager | 待填写 |
| 题面、附件、预期漏洞与修复方式 | 待填写 |
| 可见性 | Private / Shared |
| Runtime | Container / PerTeam / AwdRotation |
| 命名服务（1–64）与镜像 | 每项填写名称、镜像 tag 或 digest |
| 服务资源 | 每项 CPU 核数、内存 MiB |
| 命令、参数、环境与内部端口 | 待填写 |
| Runtime 访问入口 | 服务名、容器端口、Participants、URL 模板 |

不填写 Provider、Runner Pool、PID 上限、Compose 或容器安全开关。Docker 使用服务自己的随机宿主端口映射；不能写死宿主端口。

## Flag Store

每个 Store 单独填写；Store 与 Runtime 服务不是同一概念。

| 字段 | 内容 |
| --- | --- |
| 稳定 StoreId / 名称 | 由编辑器创建后记录 |
| 投放方式 | BusinessChecker / RunnerCommand |
| 目标命名服务 | 待填写 |
| 历史保存能力 | 必须覆盖已发行规则要求的历史窗口 |
| 业务写入与读取流程 | 待填写，说明如何精确读回原值 |
| 私有读取上下文 / 公开定位信息 | 分开说明，不记录真实秘密 |
| Runner 命令及超时 | 仅 RunnerCommand 填写，幂等并正确引用变量 |
| 重启、故障与 Runtime 重置行为 | 不自动伪造历史投放或补回历史数据 |

命令示例：

```sh
mkdir -p "/dev/shm/flags/${STORE_ID}"
printf '%s' "${FLAG}" > "/dev/shm/flags/${STORE_ID}/${FLAG_ID}"
```

不要覆盖单个 `/dev/shm/flag`。同一次正式发行重投使用同一秘密，按完整 UTF-8 字节保存与读取。

## Checker

| 项目 | 内容 |
| --- | --- |
| 镜像、命令、默认用户 | 待填写 |
| 目标服务与内部端口 | 待填写 |
| 单次预算 | 待填写，不能超出任务 deadline |
| 连接探测 | 待填写，区分目标拒绝/超时与平台异常 |
| 功能探测 | 真实业务流程与预期结果 |
| 当前 Flag 写入/读取 | requiresWrite=true 才写入 |
| 历史 Flag 读取 | 全部任务项，当前写入失败也继续尝试 |
| 原因码 | 使用生成契约枚举，不能上报自由文本故障码 |

通过 `NOCTF_AWD_TASK_URL` 和 Bearer Token 读取任务；命名服务地址来自 `NOCTF_AWD_TARGETS`。回调包含 connection、functionality、全部 flags 的 write/read 与 observedAt，不指定健康或计分。日志不包含 Token、Flag、私有上下文或目标响应正文。

## 比赛规则抄录

| 项目 | 默认与交付记录 |
| --- | --- |
| 加固 / 轮长 / 间隔 | 0 / 180 / 0 秒；实际值：待填写 |
| 接收窗口 / 历史窗口 | 默认 5 轮、联动；实际值：待填写 |
| 每 Store 发行数 / 权重 | 默认 1 / 1；实际值：待填写 |
| 计分预设 / ATK、DEF、SLA | 默认固定 / 50、100、100；实际值：待填写 |
| SLA 系数 | OK=1、RECOVERING=0.5、MUMBLE/OFFLINE=0；InternalError 待裁定 |
| Checker 周期 / 超时 / 重检 | 30 秒 / 30 秒 / 同轮最多两次、间隔 5 秒 |
| 结束方式 / 尾期 | 默认结束关闭新提交；实际值：待填写 |
| 同分排序 | 攻击分、正常题轮数、捕获数降序，最后攻击时间、注册时间升序 |
| 覆盖值、下一轮变更、历史修订 | 待填写，0/false 不等于继承 |

Flag 外观默认 `[SECURE]` 安全主体。不要填写派生密钥或低熵替代模板。

## 交付与验证

- [ ] 两队运行、轮换、跨轮首次捕获、同队跨轮重复、自己/过期/未知 Flag。
- [ ] 幂等投放与精确读取，多 Store/多 Flag 不丢项、不放大预算。
- [ ] 当前写入失败、历史丢失、业务失败、连接失败与平台异常分别验证。
- [ ] 历史丢失后当前正常时为 RECOVERING；重写历史不得掩盖故障。
- [ ] 执行超时和漏回执保持待裁定，重复回调不能覆盖已确认结果。
- [ ] 暂停、恢复、轮间间隔、收官、尾期和资源回收。
- [ ] 大屏可同时健康与捕获；规则、计分解释与管理端一致。
- [ ] 提供源码、构建命令、可拉取镜像、漏洞利用与修复说明、测试记录。

测试记录：环境、镜像版本、执行命令、通过结果、已知限制、负责人均待填写。可运行基础包见 [AWD Starter Kit](starter-kits/awd/README.md)。
